package com.example.mentorme.adapters;

public class ChatAdapter {
}
